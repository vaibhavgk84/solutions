using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Web.Services.Protocols;
using ws1.WebReference;

namespace ws1
{
    class Program
    {
        static void Main(string[] args)
        {
            string token = "";
            AuthenticationBroker ab = new WebReference.AuthenticationBroker();
            NetworkCredential nc = new NetworkCredential("admin", "607920b64fe136f9ab2389e371852af2");
            ab.Credentials = nc;

            FileDownloadParameters fdp = new FileDownloadParameters();
            fdp.dbName = "InnovatorSolutions11SP9";
            fdp.fileId = "38B4C993770F4D1A828DBFA438EFB3C8";// File ID for the file which is not attached to any document
            
            token =ab.GetFileDownloadToken(fdp);
            Console.WriteLine("TOKEN FOR FILE WHICH IS NOT ATTACHED TO DOCUMENT [FileID-67833F75DEC54EB684D8EE856C9C05CE]:");
            Console.WriteLine(token);
            try
            {
                fdp.fileId = "2EB59E79F5D440EA9B47E0A5C21D2149";// File ID for the file which is attached to document
                token = ab.GetFileDownloadToken(fdp);
                Console.WriteLine(token);
            }
            catch(Exception ex)
            {
                Console.WriteLine("----------------------------------------------------------------------------------------------");
                Console.WriteLine("ERROR: TOKEN FOR FILE WHICH IS ATTACHED TO DOCUMENT [FileID-2EB59E79F5D440EA9B47E0A5C21D2149]:");
                Console.WriteLine(ex.StackTrace);
                Console.WriteLine("----------------------------------------------------------------------------------------------");
                Console.ReadKey();
                
            }

        }
    }
}
